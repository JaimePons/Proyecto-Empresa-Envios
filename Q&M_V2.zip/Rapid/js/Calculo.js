    function calcula()
    {
       var ancho = document.fdatos.ancho.value;
       var largo = document.fdatos.largo.value;
       var peso = document.fdatos.peso.value;
       var altura = document.fdatos.altura.value;
       var dato =  document.getElementById("lista");
       var valor = dato.options[lista.selectedIndex].value;  // .text
        
       let resultado = ancho * largo * peso * altura * valor;
       document.getElementById("salida").innerHTML = resultado;    
    }
